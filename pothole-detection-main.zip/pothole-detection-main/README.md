# pothole-detection
Potholes can be a real pain, literally and metaphorically! There are a few cool ways people are trying to tackle this issue. One is using technology like cameras and sensors to detect potholes in real-time. Some cities are experimenting with smart infrastructure that can identify and report potholes automatically.
